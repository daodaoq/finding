package com.finding.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.finding.entity.Contact;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ContactMapper extends BaseMapper<Contact> {}
