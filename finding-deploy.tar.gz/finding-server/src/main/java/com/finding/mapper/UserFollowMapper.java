package com.finding.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.finding.entity.UserFollow;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserFollowMapper extends BaseMapper<UserFollow> {
}
